#!/usr/bin/env bash
# Installa il tema icone "Ticly Sequoia" per KDE Plasma.
# Uso: ./install.sh              -> solo utente (~/.local/share/icons)
#      sudo ./install.sh --system -> per tutti gli utenti (/usr/share/icons)
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"
if [[ "${1:-}" == "--system" ]]; then
  DEST="/usr/share/icons/ticly-sequoia"
else
  DEST="${XDG_DATA_HOME:-$HOME/.local/share}/icons/ticly-sequoia"
fi

rm -rf "$DEST"
mkdir -p "$DEST"
cp "$SRC/index.theme" "$DEST/"
for d in "$SRC"/scalable "$SRC"/symbolic "$SRC"/[0-9]*x[0-9]*; do
  [[ -d "$d" ]] && cp -r "$d" "$DEST/"
done
gtk-update-icon-cache -f -t "$DEST" 2>/dev/null || true

echo "Installato in $DEST"
echo "Attivalo da: Impostazioni di sistema > Aspetto > Icone > Ticly Sequoia"
